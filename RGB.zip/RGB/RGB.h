#ifndef LED_H
#define LED_H

#include <Arduino.h>

class RGB {
  
  private:
    byte redPin;
    byte greenPin;
    byte bluePin;
    
  public:
    // Setup pin LED and call init()
    RGB(byte redPin,byte greenPin, byte bluePin);

    // setup rgb
    void start();
    //setColor
    void setColor(int red, int green, int blue);
    // setup off
    void off();
};

#endif
